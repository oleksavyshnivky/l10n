<?php

$params = array(
	'dbhost'	=>	'127.0.0.1',
	'dbname'	=>	'devPPDB',
	'dbuser'	=>	'root',
	'dbpass'	=>	''
);

$db = new db($params);
