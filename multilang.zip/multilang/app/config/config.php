<?php

const CONFIG = [
	'name'				=>	'Мультимовність',		// Ім'я проекту
	'default_language'	=>	'uk',
];
